<!--View contenant ma page d'accueil-->
<?= $this->extend('layout') ?>

<?= $this->section('title') ?>Accueil - LeanBnB<?= $this->endSection() ?>

<?= $this->section('script') ?>
    <!--Inclure le fichier js-->
<?= $this->endSection() ?>

<?= $this->section('content') ?>
    
        <h1 class="my-3">Bienvenue sur LeanBnB, notre plateforme de locations de maisons.</h1>
        <h2>Découvrez nos maisons de vacances</h2>
        <p>Explorez et réservez votre prochain séjour en toute simplicité.</p>
        
        <section>
            <h3>Quelques fonctionnalités :</h3>
            <ul>
                <a href="<?= base_url('/maisons') ?>" class="btn btn-secondary">Voir nos maisons ?</a>
                <a href="<?= base_url('/reservation') ?>" class="btn btn-secondary">Réserver maintenant ?</a>
            </ul>
        </section>

<?= $this->endSection() ?>