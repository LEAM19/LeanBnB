<?= $this->extend('layout') ?>
<?= $this->section('title') ?>Ajouter une Maison<?= $this->endSection() ?>
<?= $this->section('script') ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" defer></script>
<?= $this->endSection() ?>
<?= $this->section('content') ?>

<h2 class="text-center mb-4">Ajouter une nouvelle maison</h2>

<form action="<?= base_url('/admin_maisons/ajouter') ?>" method="post" enctype="multipart/form-data" class="w-50 mx-auto">
    <div class="mb-3">
        <label for="nom" class="form-label">Nom</label>
        <input type="text" name="nom" id="nom" class="form-control" required>
    </div>
    <div class="mb-3">
        <label for="description" class="form-label">Description</label>
        <textarea name="description" id="description" class="form-control" rows="3" required></textarea>
    </div>
    <div class="mb-3">
        <label for="ville" class="form-label">Ville</label>
        <input type="text" name="ville" id="ville" class="form-control" required>
    </div>
    <div class="mb-3">
        <label for="pays" class="form-label">Pays</label>
        <input type="text" name="pays" id="pays" class="form-control" required>
    </div>
    <div class="mb-3">
        <label for="prix_basse" class="form-label">Prix Basse Saison</label>
        <input type="number" name="prix_basse" id="prix_basse" class="form-control" required>
    </div>
    <div class="mb-3">
        <label for="prix_moyenne" class="form-label">Prix Moyenne Saison</label>
        <input type="number" name="prix_moyenne" id="prix_moyenne" class="form-control" required>
    </div>
    <div class="mb-3">
        <label for="prix_haute" class="form-label">Prix Haute Saison</label>
        <input type="number" name="prix_haute" id="prix_haute" class="form-control" required>
    </div>
    <div class="mb-3">
        <label for="image" class="form-label">Image</label>
        <input type="file" name="image" id="image" class="form-control">
    </div>
    <div class="mb-3">
        <label for="photos_supplementaires" class="form-label">Photos supplémentaires</label>
        <input type="file" name="photos_supplementaires[]" id="photos_supplementaires" class="form-control" multiple accept="image/*">
    </div>

    <button type="submit" class="btn btn-success">Ajouter</button>
</form>

<?= $this->endSection() ?>