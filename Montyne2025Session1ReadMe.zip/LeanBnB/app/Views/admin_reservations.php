<?= $this->extend('layout') ?>

<?= $this->section('title') ?>Réservations - Admin<?= $this->endSection() ?>

<?= $this->section('script') ?>
<script src="<?= base_url('public/assets/js/admin_reservations.js') ?>"></script>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<h1 class="text-center my-4">Liste des Réservations</h1>

<div class="table-responsive px-4">
    <table id="table-utilisateurs" class="table table-bordered table-hover">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Maison</th>
                <th>Client</th>
                <th>Date d'arrivée</th>
                <th>Date de départ</th>
                <th>Montant</th>
                <th>Statut</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($reservations as $resa): ?>
                <tr>
                    <td><?= esc($resa['IDreservation']) ?></td>
                    <td><?= esc($resa['nom_maison']) ?></td>
                    <td><?= esc($resa['prenom']) ?> <?= esc($resa['nom']) ?></td>
                    <td><?= esc($resa['date_arrive']) ?></td>
                    <td><?= esc($resa['date_depart']) ?></td>
                    <td><?= esc($resa['montant']) ?> €</td>

                    
                    <td>
                        <?php if ($resa['statut'] === 'payé'): ?>
                            <span class="badge bg-success">Payé</span>
                        <?php elseif ($resa['statut'] === 'en_attente_validation'): ?>
                            <span class="badge bg-warning text-dark">En attente de confirmation</span>
                        <?php elseif ($resa['statut'] === 'en attente'): ?>
                            <span class="badge bg-secondary">En attente</span>
                        <?php elseif ($resa['statut'] === 'annulée'): ?>
                            <span class="badge bg-warning text-dark">Annulée</span>
                        <?php endif; ?>
                    </td>

                    
                    <td>
                        <?php if ($resa['statut'] === 'en_attente_validation'): ?>
                            <a href="<?= base_url('/admin_reservations/confirmer/' . $resa['IDreservation']) ?>" class="btn btn-success btn-sm mb-1">Valider</a>
                        <?php endif; ?>

                        <?php if ($resa['statut'] !== 'payé' &&  $resa['statut'] !== 'annulée'): ?>
                            <a href="<?= base_url('/admin_reservations/annuler/' . $resa['IDreservation']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Confirmer l\'annulation ?');">Annuler</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?= $this->endSection() ?>