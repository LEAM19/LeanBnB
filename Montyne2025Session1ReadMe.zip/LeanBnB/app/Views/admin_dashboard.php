<?= $this->extend('layout') ?>

<?= $this->section('title') ?>Espace Admin - LeanBnB<?= $this->endSection() ?>

<?= $this->section('content') ?>

<h1 class="mb-4 text-center">Espace Administrateur</h1>

<?php if (session()->getFlashdata('success')) : ?>
    <div class="alert alert-success text-center"><?= session()->getFlashdata('success') ?></div>
<?php endif; ?>

<?php if (session()->getFlashdata('error')) : ?>
    <div class="alert alert-danger text-center"><?= session()->getFlashdata('error') ?></div>
<?php endif; ?>

<div class="text-center">
    <p class="mb-3">Bienvenue dans votre espace administrateur. Que souhaitez-vous faire ?</p>

    <a href="<?= base_url('/admin_maisons') ?>" class="btn btn-outline-primary d-block my-2">Gérer les maisons</a>

    <a href="<?= base_url('/admin_utilisateurs') ?>" class="btn btn-outline-secondary d-block my-2">Gérer les utilisateurs</a>

    <a href="<?= base_url('/admin_reservations') ?>" class="btn btn-outline-primary d-block my-2">Gérer les réservations</a>

    <a href="<?= base_url('/admin_indisponibilites') ?>" class="btn btn-outline-secondary d-block my-2">Gérer les périodes d'indisponibilités</a>

    <a href="<?= base_url('/admin_saisons') ?>" class="btn btn-outline-primary d-block my-2">Gérer les saisons</a>
</div>

<?= $this->endSection() ?>