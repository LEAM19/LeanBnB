<?php foreach ($maisons as $maison): ?>
    <div class="maison-card" data-pays="<?= esc(strtolower($maison['pays'])) ?>"
         style="width: 100%; max-width: 960px; border: 1px solid #ccc; border-radius: 12px;
                overflow: hidden; margin: 30px auto; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">

        <!-- Image principale -->
        <img src="<?= base_url($maison['image']) ?>" alt="<?= esc($maison['nom']) ?>"
             style="width: 100%; height: 300px; object-fit: cover;">

        <!-- Galerie supplémentaire -->
        <?php if (!empty($maison['photos'])): ?>
            <div id="carousel-<?= $maison['IDmaison'] ?>" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <?php foreach ($maison['photos'] as $index => $photo): ?>
                        <div class="carousel-item <?= $index === 0 ? 'active' : '' ?>">
                            <img src="<?= base_url($photo['chemin']) ?>" class="d-block w-100"
                                 alt="Photo supplémentaire"
                                 style="height: 300px; object-fit: cover;">
                        </div>
                    <?php endforeach; ?>
                </div>
                <button class="carousel-control-prev" type="button"
                        data-bs-target="#carousel-<?= $maison['IDmaison'] ?>" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                </button>
                <button class="carousel-control-next" type="button"
                        data-bs-target="#carousel-<?= $maison['IDmaison'] ?>" data-bs-slide="next">
                    <span class="carousel-control-next-icon"></span>
                </button>
            </div>
        <?php endif; ?>

        <div style="padding: 20px;">
            <h2><?= esc($maison['nom']) ?></h2>
            <p><strong><?= esc($maison['pays']) ?></strong></p>
            <p><strong><?= esc($maison['ville']) ?></strong></p>
            <p><?= esc($maison['description']) ?></p>
            <p><strong>Basse saison :</strong> <?= esc($maison['prix_basse']) ?> €</p>
            <p><strong>Moyenne saison :</strong> <?= esc($maison['prix_moyenne']) ?> €</p>
            <p><strong>Haute saison :</strong> <?= esc($maison['prix_haute']) ?> €</p>
        </div>
    </div>
<?php endforeach; ?>