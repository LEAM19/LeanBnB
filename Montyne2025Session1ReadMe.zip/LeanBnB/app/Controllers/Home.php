<?php

namespace App\Controllers;
/* Controllers pour ma page d'accueil */
class Home extends BaseController
{
    public function index(): string
    {
        return view('welcome_message');
    }
	public function details(): string
	{
		return view('details');
	}
}  