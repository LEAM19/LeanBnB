<?php

namespace App\Controllers;

use App\Models\MaisonModel; // ⬅️ N'oublie pas d'importer ton modèle

class Maisons extends BaseController
{
    public function maisons()
    {
        $maisonModel = new \App\Models\MaisonModel();
        $photoModel = new \App\Models\PhotoModel();

        $maisons = $maisonModel->findAll();

        foreach ($maisons as &$maison) {
            $maison['photos'] = $photoModel->where('IDmaison', $maison['IDmaison'])->findAll();
        }

        return view('maisons', ['maisons' => $maisons]);
    }

    public function viewreservation()
    {
        return view('reservation');
    }

    public function maisonsParPays()
    {
        $pays = $this->request->getPost('pays');
        $maisonModel = new \App\Models\MaisonModel();
        $photoModel = new \App\Models\PhotoModel();

        if ($pays === 'tous') {
            $maisons = $maisonModel->findAll();
        } else {
            $maisons = $maisonModel->where('pays', $pays)->findAll();
        }

        foreach ($maisons as &$maison) {
            $maison['photos'] = $photoModel->where('IDmaison', $maison['IDmaison'])->findAll();
        }

        return view('partials/maisons_liste', ['maisons' => $maisons]);
    }
}
