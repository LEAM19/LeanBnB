<?php

namespace App\Controllers;

use App\Models\UtilisateurModel;

class Profil extends BaseController
{
    public function dashboard()
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') == 'bloque') {
            return redirect()->to('/authentification');
        }

        return view('dashboard');
    }

    public function modifier()
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') == 'bloque') {
            return redirect()->to('/authentification');
        }

        $userModel = new UtilisateurModel();
        $user = $userModel->find(session()->get('user_id'));

        return view('modifier_profil', ['user' => $user]);
    }

    public function enregistrerModification()
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') == 'bloque') {
            return redirect()->to('/authentification');
        }
    
        $userModel = new UtilisateurModel();
        $userId = session()->get('user_id');
    
        $data = [
            'nom'       => $this->request->getPost('nom'),
            'prenom'    => $this->request->getPost('prenom'),
            'telephone' => $this->request->getPost('telephone'),
            'email'     => $this->request->getPost('email'),
        ];
    
        $newPassword = $this->request->getPost('new_password');
        $confirmPassword = $this->request->getPost('confirm_password');
    
        if (!empty($newPassword)) {
            if ($newPassword !== $confirmPassword) {
                return redirect()->back()->with('error', 'Les mots de passe ne correspondent pas.');
            }
    
            $data['mdp'] = password_hash($newPassword, PASSWORD_DEFAULT);
        }
    
        $photo = $this->request->getFile('photo_profil');
        if ($photo && $photo->isValid() && !$photo->hasMoved()) {
            $newName = $photo->getRandomName();
            $photo->move('uploads/photos_profil', $newName);
            $data['photo_profil'] = 'uploads/photos_profil/' . $newName;
            session()->set('user_photo', $data['photo_profil']); // MAJ session
        }
    
        $userModel->update($userId, $data);
    
        session()->set('user_nom', $data['nom']);
        session()->set('user_prenom', $data['prenom']);
        session()->set('user_email', $data['email']);
        session()->set('user_telephone', $data['telephone']);
    
        return redirect()->to('/dashboard')->with('success', 'Profil mis à jour avec succès.');
    }
}