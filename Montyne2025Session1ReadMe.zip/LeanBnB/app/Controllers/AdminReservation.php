<?php

namespace App\Controllers;

use App\Models\ReservationModel;
use App\Models\MaisonModel;
use App\Models\UtilisateurModel;

class AdminReservation extends BaseController
{
    public function lister()
    {
        if (!session()->get('isLoggedIn') || session()->get('user_role') !== 'administrateur') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }

        $reservationModel = new ReservationModel();
        $reservations = $reservationModel
            ->select('reservation.*, utilisateur.nom, utilisateur.prenom, maison.nom AS nom_maison')
            ->join('utilisateur', 'utilisateur.IDutilisateur = reservation.IDutilisateur')
            ->join('maison', 'maison.IDmaison = reservation.IDmaison')
            ->orderBy('reservation.date_arrive', 'DESC')
            ->findAll();
        return view('admin_reservations', ['reservations' => $reservations]);
    }

   public function confirmerPaiement($id = null)
    {
        if (!session()->get('isLoggedIn') || session()->get('user_role') !== 'administrateur') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }

        $reservationModel = new \App\Models\ReservationModel();
        $reservation = $reservationModel->find($id);

        if (!$reservation) {
            return redirect()->to('/admin_reservations')->with('error', 'Réservation introuvable.');
        }

        $reservationModel->update($id, ['statut' => 'payé']);

        return redirect()->to('/admin_reservations')->with('success', 'Paiement confirmé avec succès.');
    }


    public function confirmer($id)
    {
        $model = new ReservationModel();
        $model->update($id, ['statut' => 'payé']);
        return redirect()->to('/admin_reservations')->with('success', 'Paiement confirmé.');
    }

    public function annuler($id = null)
    {
        if (!session()->get('isLoggedIn') || session()->get('user_role') !== 'administrateur') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }

        $reservationModel = new \App\Models\ReservationModel();
        $reservation = $reservationModel->find($id);

        if (!$reservation) {
            return redirect()->to('/admin_reservations')->with('error', 'Réservation introuvable.');
        }

        $reservationModel->update($id, ['statut' => 'annulée']);
            return redirect()->to('/admin_reservations')->with('success', 'Réservation annulée (statut mis à jour).');
    }

}