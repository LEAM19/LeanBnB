<?php

namespace App\Controllers;

use App\Models\UtilisateurModel;

class AdminUtilisateur extends BaseController
{
    public function gererUtilisateurs()
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') == 'bloque') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }

        $utilisateurModel = new UtilisateurModel();
        $utilisateurs = $utilisateurModel->findAll();

        return view('admin_utilisateurs', ['utilisateurs' => $utilisateurs]);
    }

    public function bloquer($id)
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') == 'bloque') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }

        $utilisateurModel = new UtilisateurModel();
        $utilisateurModel->update($id, ['statut' => 'bloque']);

        return redirect()->to('/admin_utilisateurs')->with('success', 'Utilisateur bloqué.');
    }

    public function debloquer($id)
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') == 'bloque') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }

        $utilisateurModel = new UtilisateurModel();
        $utilisateurModel->update($id, ['statut' => 'debloque']);

        return redirect()->to('/admin_utilisateurs')->with('success', 'Utilisateur débloqué.');
    }

    public function promouvoir($id)
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') == 'bloque') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }

        $utilisateurModel = new UtilisateurModel();
        $utilisateurModel->update($id, ['role' => 'administrateur']);

        return redirect()->to('/admin_utilisateurs')->with('success', 'Utilisateur promu administrateur.');
    }
    public function anonymiser($id)
    {
        $model = new \App\Models\UtilisateurModel();
        if ($model->anonymiser($id)) {
            return redirect()->to('/admin_utilisateurs')->with('message', 'Utilisateur anonymisé avec succès.');
        } else {
            return redirect()->back()->with('error', 'Échec de l\'anonymisation.');
        }
    }
}