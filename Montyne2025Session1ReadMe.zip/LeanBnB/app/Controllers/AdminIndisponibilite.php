<?php

namespace App\Controllers;

use App\Models\IndisponibiliteModel;
use App\Models\MaisonModel;

class AdminIndisponibilite extends BaseController
{
    public function viewAdminIndisponibilites()
    {
        if (!session()->get('isLoggedIn') || session()->get('user_role') !== 'administrateur') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }
    
        $maisonModel = new \App\Models\MaisonModel();
        $indispoModel = new \App\Models\IndisponibiliteModel();
    
        $maisons = $maisonModel->findAll();
    
        $indisponibilites = $indispoModel
            ->select('indisponibilite.*, maison.nom AS nom_maison')
            ->join('maison', 'maison.IDmaison = indisponibilite.IDmaison')
            ->findAll();
    
        return view('admin_indisponibilites', [
            'maisons' => $maisons,
            'indisponibilites' => $indisponibilites
        ]);
    }    

    public function ajouter()
    {
        $model = new IndisponibiliteModel();

        $data = [
            'IDmaison'    => $this->request->getPost('IDmaison'),
            'date_debut'  => $this->request->getPost('date_debut'),
            'date_fin'    => $this->request->getPost('date_fin'),
            'motif'       => $this->request->getPost('motif')
        ];

        $model->insert($data);

        return redirect()->to('/admin_indisponibilites')->with('success', 'Indisponibilité ajoutée.');
    }

    public function supprimer($id = null)
    {
        if (!session()->get('isLoggedIn') || session()->get('user_role') !== 'administrateur') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }
    
        $model = new \App\Models\IndisponibiliteModel();
        $indispo = $model->find($id);
    
        if (!$indispo) {
            return redirect()->to('/admin_indisponibilites')->with('error', 'Indisponibilité introuvable.');
        }
    
        $model->delete($id);
        return redirect()->to('/admin_indisponibilites')->with('success', 'Indisponibilité supprimée.');
    }
    
    public function modifier($id = null)
    {
        if (!session()->get('isLoggedIn') || session()->get('user_role') !== 'administrateur') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }
    
        $model = new \App\Models\IndisponibiliteModel();
        $maisonModel = new \App\Models\MaisonModel();
    
        $indispo = $model->find($id);
        $maisons = $maisonModel->findAll();
    
        if (!$indispo) {
            return redirect()->to('/admin_indisponibilites')->with('error', 'Indisponibilité introuvable.');
        }
    
        return view('modifier_indisponibilite', [
            'indisponibilite' => $indispo,
            'maisons' => $maisons
        ]);
    }
    
    public function enregistrerModification($id = null)
    {
        if (!session()->get('isLoggedIn') || session()->get('user_role') !== 'administrateur') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }
    
        $model = new \App\Models\IndisponibiliteModel();
    
        $data = [
            'IDmaison'   => $this->request->getPost('IDmaison'),
            'date_debut' => $this->request->getPost('date_debut'),
            'date_fin'   => $this->request->getPost('date_fin'),
            'motif'      => $this->request->getPost('motif'),
        ];
    
        $model->update($id, $data);
    
        return redirect()->to('/admin_indisponibilites')->with('success', 'Indisponibilité modifiée.');
    }
    
}