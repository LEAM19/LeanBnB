<?php namespace App\Models;

use CodeIgniter\Model;

/* Model pour ma table `Saison` */

class SaisonModel extends Model
{
    protected $table = 'saison';
    protected $primaryKey = 'IDsaison';
    protected $returnType = 'array';
    protected $allowedFields = ['nom', 'date_debut', 'date_fin']; 
}