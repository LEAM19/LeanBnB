<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('Home/index', 'Home::index');
$routes->get('/', 'Home::details'); /*Renvoie une vue sur ma page d'accueil*/
$routes->get('/authentification', 'Authentification::viewlogin'); /*Renvoie une vue sur ma page connexion*/
$routes->get('/inscription', 'Authentification::viewinscription'); /*Renvoie une vue sur ma page inscription*/
$routes->get('/maisons', 'Maisons::maisons'); /*Renvoie une vue sur ma page maison*/
$routes->post('/inscription', 'Authentification::inscription'); // Route pour enregistrer un utilisateur
$routes->post('/authentification', 'Authentification::login'); //Route pour la connexion
$routes->get('/logout', 'Authentification::logout'); //Route pour la déconnexion
$routes->get('/dashboard', 'Profil::dashboard'); // view Mon profil (utilisateur)
$routes->get('/modifier_profil', 'Profil::modifier');
$routes->post('/modifier_profil', 'Profil::enregistrerModification');
$routes->get('/reservation', 'Reservation::viewreservation');
$routes->post('/reservation/submit', 'Reservation::submit');
$routes->get('/mes_reservations', 'Reservation::mesReservations');
$routes->get('/reservation/annuler/(:num)', 'Reservation::annuler/$1');
$routes->get('/reservation/modifier/(:num)', 'Reservation::modifierFormulaire/$1');
$routes->post('/reservation/modifier/(:num)', 'Reservation::validerFormulaire/$1');
$routes->get('/admin', 'AdminMaisons::dashboard');
$routes->get('/admin_maisons', 'AdminMaisons::gererMaisons');
$routes->get('/admin_maisons/ajouter', 'AdminMaisons::ajouterMaison');
$routes->post('/admin_maisons/ajouter', 'AdminMaisons::enregistrerMaison');
$routes->get('/admin_maisons/supprimer/(:num)', 'AdminMaisons::supprimerMaison/$1');
$routes->get('/admin_maisons/modifier/(:num)', 'AdminMaisons::modifierMaison/$1');
$routes->post('/admin_maisons/modifier/(:num)', 'AdminMaisons::enregistrerModificationMaison/$1');
$routes->get('/admin_utilisateurs', 'AdminUtilisateur::gererUtilisateurs');
$routes->get('/admin_utilisateurs/bloquer/(:num)', 'AdminUtilisateur::bloquer/$1');
$routes->get('/admin_utilisateurs/debloquer/(:num)', 'AdminUtilisateur::debloquer/$1');
$routes->get('/admin_utilisateurs/promouvoir/(:num)', 'AdminUtilisateur::promouvoir/$1');
$routes->get('/admin_reservations', 'AdminReservation::lister');
$routes->get('/admin_reservations/payer/(:num)', 'AdminReservation::confirmerPaiement/$1');
$routes->get('/admin_indisponibilites', 'AdminIndisponibilite::viewAdminIndisponibilites');
$routes->post('/admin_indisponibilites/ajouter', 'AdminIndisponibilite::ajouter');
$routes->get('/admin_indisponibilites/supprimer/(:num)', 'AdminIndisponibilite::supprimer/$1');
$routes->get('/admin_indisponibilites/modifier/(:num)', 'AdminIndisponibilite::modifier/$1');
$routes->post('/admin_indisponibilites/modifier/(:num)', 'AdminIndisponibilite::enregistrerModification/$1');
$routes->get('/admin_saisons', 'AdminSaisons::viewSaisons');
$routes->post('/admin_saisons/ajouter', 'AdminSaisons::ajouter');
$routes->get('/admin_saisons/modifier/(:num)', 'AdminSaisons::modifier/$1'); 
$routes->post('/admin_saisons/modifier/(:num)', 'AdminSaisons::enregistrerModification/$1'); 
$routes->get('/admin_saisons/supprimer/(:num)', 'AdminSaisons::supprimer/$1'); 
$routes->post('/get-saison', 'Reservation::getSaison');
$routes->post('/reservation/payer/(:num)', 'Reservation::signalerPaiement/$1');
$routes->get('admin_reservations/confirmer/(:num)', 'AdminReservation::confirmerPaiement/$1');
$routes->get('admin_reservations/annuler/(:num)', 'AdminReservation::annuler/$1');
$routes->get('admin_utilisateurs/anonymiser/(:num)', 'AdminUtilisateur::anonymiser/$1');
$routes->post('maisons_par_pays', 'Maisons::maisonsParPays');