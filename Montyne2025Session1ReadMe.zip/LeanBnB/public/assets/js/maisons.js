document.addEventListener('DOMContentLoaded', function () {
    const filtre = document.getElementById('filtre-pays');

    filtre.addEventListener('change', function () {
        console.log("Changement détecté : ", filtre.value);

        const selected = filtre.value;
        const xhr = new XMLHttpRequest();

        // 👉 utilise l’URL absolue construite dynamiquement
        const baseURL = document.querySelector('base')?.href || '/';
        xhr.open('POST', baseURL + 'maisons_par_pays', true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                console.log("Réponse HTTP : ", xhr.status);
                if (xhr.status === 200) {
                    document.getElementById('contenu-maisons').innerHTML = xhr.responseText;
                } else {
                    console.warn("Erreur AJAX : " + xhr.status);
                }
            }
        };

        xhr.send('pays=' + encodeURIComponent(selected));
    });
});