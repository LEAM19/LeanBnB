<?php namespace App\Models;

use CodeIgniter\Model;

/* Model pour ma table `Maison` */

class MaisonModel extends Model
{
    protected $table = 'maison';
    protected $primaryKey = 'IDmaison';
    protected $returnType = 'array';
    protected $allowedFields = ['nom', 'description', 'ville', 'pays', 'prix_basse', 'prix_moyenne', 'prix_haute', 'image']; 
}