<?php namespace App\Models;

use CodeIgniter\Model;

/* Model pour ma table `Indisponiblilite` */

class IndisponibiliteModel extends Model
{
    protected $table = 'indisponibilite';
    protected $primaryKey = 'IDindisponibilite';
    protected $returnType = 'array';
    protected $allowedFields = ['date_debut', 'date_fin', 'motif', 'IDmaison']; 
}