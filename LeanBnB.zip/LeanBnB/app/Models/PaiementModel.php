<?php namespace App\Models;

use CodeIgniter\Model;

/* Model pour ma table `Paiement` */

class PaiementModel extends Model
{
    protected $table = 'paiement';
    protected $primaryKey = 'IDpaiement';
    protected $returnType = 'array';
    protected $allowedFields = ['montant', 'etat', 'IDreservation']; 
}