<?php namespace App\Models;

use CodeIgniter\Model;

/* Model pour ma table `Photo` */

class PhotoModel extends Model
{
    protected $table = 'photo';
    protected $primaryKey = 'IDphoto';
    protected $returnType = 'array';
    protected $allowedFields = ['chemin', 'description', 'IDmaison']; 
}