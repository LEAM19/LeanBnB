<?php namespace App\Models;

use CodeIgniter\Model;

/* Model pour ma table `Reservation` */

class ReservationModel extends Model
{
    protected $table = 'reservation';
    protected $primaryKey = 'IDreservation';
    protected $returnType = 'array';
    protected $allowedFields = ['date_arrive', 'date_depart', 'montant', 'statut' , 'IDmaison', 'IDutilisateur', 'date_reservation']; 
    public $useTimestamps = false;
}