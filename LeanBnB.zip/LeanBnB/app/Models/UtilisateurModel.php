<?php namespace App\Models;

use CodeIgniter\Model;

/* Model pour ma table `Utilisateur` */

class UtilisateurModel extends Model
{
    protected $table = 'utilisateur';
    protected $primaryKey = 'IDutilisateur';
    protected $returnType = 'array';
    protected $allowedFields = ['nom', 'prenom', 'telephone', 'email', 'mdp', 'role', 'photo_profil', 'statut']; 

    public function anonymiser($id)
    {
        return $this->update($id, [
            'nom' => 'Anonyme'.$id,
            'prenom' => '',
            'telephone' => '',
            'email' => 'ano_'.$id.'@nyme.com',
            'mdp' => '',
            'photo_profil' => null,
            'statut' => 'delete',
            'role' =>'utilisateur'
        ]);
    }
}
