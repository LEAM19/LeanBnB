<?php

namespace App\Controllers;

use App\Models\UtilisateurModel;

class Authentification extends BaseController
{
    public function viewlogin()
    {
        return view('authentification');
    }  

    public function viewinscription()
    {
        return view('inscription');
    }

   public function inscription()
    {
        $model = new UtilisateurModel();

        $password = $this->request->getPost('password');
        
        if (!preg_match('/^(?=.*[A-Z])(?=.*\d).{5,}$/', $password)) {
            return redirect()->back()->with('error', 'Le mot de passe doit contenir au minimum 5 caractères, avec au moins 1 majuscule et 1 chiffre.');
        }

        // Traitement du fichier imageS
        $photo = $this->request->getFile('photo_profil');
        if ($photo && $photo->isValid() && !$photo->hasMoved()) {
            $newName = $photo->getRandomName();
            $photo->move('uploads/photos_profil', $newName);
            $photoPath = 'uploads/photos_profil/' . $newName;
        } else {
            $photoPath = 'public/images/avatar-default.png'; // Chemin par défaut si aucun fichier
        }

        $data = [
            'nom'       => $this->request->getPost('nom'),
            'prenom'    => $this->request->getPost('prenom'),
            'telephone' => $this->request->getPost('telephone'),
            'email'     => $this->request->getPost('email'),
            'mdp'       => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'role'      => 'utilisateur',
            'statut'    => 'debloque',
            'photo_profil' => $photoPath
        ];

        $model->insert($data);

        return redirect()->to('/authentification')->with('success', 'Inscription réussie. Connectez-vous.');
    }


    public function login()
    {
        $model = new \App\Models\UtilisateurModel();
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');
    
        $user = $model->where('email', $email)->first();
    
        if (!$user) {
            return redirect()->to('/authentification')->with('error', 'Email non reconnu.');
        }
    
        if (!password_verify($password, $user['mdp'])) {
            return redirect()->to('/authentification')->with('error', 'Mot de passe incorrect.');
        }
    
        if ($user['statut'] === 'bloque') {
            return redirect()->to('/authentification')->with('error', 'Votre compte est bloqué.');
        }
    
        $photo = !empty($user['photo_profil']) ? $user['photo_profil'] : 'public/images/avatar-default.png';
    
        session()->set([
            'user_id'        => $user['IDutilisateur'],
            'user_nom'       => $user['nom'],
            'user_prenom'    => $user['prenom'],
            'user_email'     => $user['email'],
            'user_telephone' => $user['telephone'],
            'user_role'      => $user['role'],
            'user_photo'     => $photo,
            'user_statut'    => $user['statut'],
            'isLoggedIn'     => true
        ]);
    
        return redirect()->to('/dashboard');
    }      
    
    public function logout()
    {
        session()->destroy();
        return redirect()->to('/');
    }
}