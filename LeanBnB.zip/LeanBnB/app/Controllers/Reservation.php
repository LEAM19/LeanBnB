<?php

namespace App\Controllers;

use App\Models\ReservationModel;
use App\Models\MaisonModel;

class Reservation extends BaseController
{
    public function viewreservation()
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') == 'bloque') {
            return redirect()->to('/authentification');
        }

        $maisonModel = new MaisonModel();
        $maisons = $maisonModel->findAll();

        return view('reservation', ['maisons' => $maisons]);
    }

   public function submit()
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') === 'bloque') {
            return redirect()->to('/authentification')->with('error', 'Vous devez être connecté pour réserver.');
        }

        $dateArrive = $this->request->getPost('date_debut');

        if (strtotime($dateArrive) < strtotime(date('Y-m-d'))) {
            return redirect()->back()->with('error', 'Vous ne pouvez pas réserver une date passée.');
        }

        $IDmaison = $this->request->getPost('maison');

        $maisonModel = new \App\Models\MaisonModel();
        $maison = $maisonModel->find($IDmaison);

        if (!$maison) {
            return redirect()->back()->with('error', 'La maison sélectionnée n\'existe pas.');
        }

        $data = [
            'date_arrive'     => $this->request->getPost('date_debut'),
            'date_depart'     => $this->request->getPost('date_fin'),
            'montant'         => $this->request->getPost('montant'),
            'IDmaison'        => $IDmaison,
            'IDutilisateur'   => session()->get('user_id'),
            'statut'          => 'en attente',
            'date_reservation'=> date('Y-m-d'),
        ];

        $indispoModel = new \App\Models\IndisponibiliteModel();
        $indispo = $indispoModel
            ->where('IDmaison', $IDmaison)
            ->where('date_debut <=', $data['date_depart'])
            ->where('date_fin >=', $data['date_arrive'])
            ->first();

        if ($indispo) {
            return redirect()->back()->with('error', 'Cette maison est indisponible pendant cette période.');
        }

        $reservationModel = new \App\Models\ReservationModel();
        $reservationExistante = $reservationModel
            ->where('IDmaison', $IDmaison)
            ->where('date_arrive <', $data['date_depart'])
            ->where('date_depart >', $data['date_arrive'])
            ->where('statut !=', 'annulée')
            ->first();

        if ($reservationExistante) {
            return redirect()->back()->with('error', 'Cette maison est déjà réservée pour les dates sélectionnées.');
        }

        if(session()->get('user_role') === 'administrateur') {
            return redirect()->back()->with('error', 'Un administrateur ne peut pas réserver, mais peut rendre une maison indisponible s\'y rendre!');
        }

        $reservationModel->insert($data);

        return redirect()->to('/mes_reservations')->with('success', 'Réservation enregistrée.');
    }

    public function mesReservations()
    {
        $reservationModel = new ReservationModel();

        $reservations = $reservationModel
            ->select('reservation.*, maison.nom')
            ->join('maison', 'maison.IDmaison = reservation.IDmaison')
            ->where('IDutilisateur', session()->get('user_id'))
            ->findAll();

        return view('mes_reservations', ['reservations' => $reservations]);
    }

    public function annuler($id = null)
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') == 'bloque') {
            return redirect()->to('/authentification');
        }

        $reservationModel = new ReservationModel();
        $reservation = $reservationModel->find($id);

        if ($reservation && $reservation['IDutilisateur'] == session()->get('user_id')) {
            // Marquer la réservation comme annulée
            $reservationModel->update($id, ['statut' => 'annulée']);
            return redirect()->to('/mes_reservations')->with('success', 'Réservation annulée.');
        }

        return redirect()->to('/mes_reservations')->with('error', 'Réservation introuvable ou non autorisée.');
    }

    public function modifierFormulaire($id = null)
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') == 'bloque') {
            return redirect()->to('/authentification');
        }

        $reservationModel = new ReservationModel();
        $maisonModel = new MaisonModel();

        $reservation = $reservationModel->find($id);
        $maisons = $maisonModel->findAll();

        if (!$reservation || $reservation['IDutilisateur'] != session()->get('user_id')) {
            return redirect()->to('/mes_reservations')->with('error', 'Réservation non autorisée.');
        }

        return view('modifier_reservation', [
            'reservation' => $reservation,
            'maisons'     => $maisons
        ]);
    }

    public function validerFormulaire($id = null)
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') == 'bloque') {
            return redirect()->to('/authentification');
        }

        $reservationModel = new ReservationModel();
        $reservation = $reservationModel->find($id);

        if (!$reservation || $reservation['IDutilisateur'] != session()->get('user_id')) {
            return redirect()->to('/mes_reservations')->with('error', 'Modification non autorisée.');
        }

        $data = [];

        if ($this->request->getPost('date_debut')) {
            $data['date_arrive'] = $this->request->getPost('date_debut');
        }

        if ($this->request->getPost('date_fin')) {
            $data['date_depart'] = $this->request->getPost('date_fin');
        }

        if (empty($data)) {
            return redirect()->back()->with('error', 'Aucune donnée à mettre à jour.');
        }

        $reservationModel->update($id, $data);

        return redirect()->to('/mes_reservations')->with('success', 'Réservation modifiée.');
    }

    public function getSaison()
    {
        $date = $this->request->getPost('date');

        $model = new \App\Models\SaisonModel();
        $saison = $model
            ->where('date_debut <=', $date)
            ->where('date_fin >=', $date)
            ->first();

        $nom = $saison ? $saison['nom'] : 'basse';

        return $this->response->setJSON(['saison' => $nom]);
    }

    public function payer($id)
    {
        $model = new ReservationModel();
        $resa = $model->find($id);

        if ($resa && $resa['IDutilisateur'] == session()->get('user_id') && $resa['statut'] === 'en attente') {
            $model->update($id, ['statut' => 'en_attente_validation']);
            return redirect()->to('/mes_reservations')->with('success', 'Paiement signalé. En attente de validation.');
        }

        return redirect()->back()->with('error', 'Action non autorisée.');
    }

    public function signalerPaiement($id = null)
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') === 'bloque') {
            return redirect()->to('/authentification')->with('error', 'Accès non autorisé.');
        }

        $reservationModel = new \App\Models\ReservationModel();
        $reservation = $reservationModel->find($id);

        if (!$reservation || $reservation['IDutilisateur'] != session()->get('user_id')) {
            return redirect()->to('/mes_reservations')->with('error', 'Réservation non trouvée ou non autorisée.');
        }

        $reservationModel->update($id, ['statut' => 'en_attente_validation']);

        return redirect()->to('/mes_reservations')->with('success', 'Votre paiement a été signalé. En attente de validation par un administrateur.');
    }
}
