<?php

namespace App\Controllers;

use App\Models\MaisonModel;

class AdminMaisons extends BaseController
{
    public function dashboard()
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') == 'bloque') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }

        return view('admin_dashboard');
    }

    public function gererMaisons()
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') == 'bloque') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }

        $maisonModel = new MaisonModel();
        $maisons = $maisonModel->findAll();

        return view('admin_maisons', ['maisons' => $maisons]);
    }

    public function ajouterMaison()
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') == 'bloque') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }

        return view('admin_maisons/ajouter');
    }

    public function enregistrerMaison()
    {
        if (!session()->get('isLoggedIn') || session()->get('user_role') !== 'administrateur') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }

        $maisonModel = new \App\Models\MaisonModel();
        $photoModel = new \App\Models\PhotoModel();

        // 1. Traitement de la photo principale
        $image = $this->request->getFile('image');
        $imagePath = null;

        if ($image && $image->isValid() && !$image->hasMoved()) {
            $newName = $image->getRandomName();
            $image->move('uploads/maisons', $newName);
            $imagePath = 'uploads/maisons/' . $newName;
        }

        // 2. Enregistrement de la maison
        $data = [
            'nom' => $this->request->getPost('nom'),
            'description' => $this->request->getPost('description'),
            'ville' => $this->request->getPost('ville'),
            'pays' => $this->request->getPost('pays'),
            'prix_basse' => $this->request->getPost('prix_basse'),
            'prix_moyenne' => $this->request->getPost('prix_moyenne'),
            'prix_haute' => $this->request->getPost('prix_haute'),
            'image' => $imagePath
        ];

        $maisonModel->insert($data);
        $idMaison = $maisonModel->getInsertID();

        // 3. Traitement des photos supplémentaires
        $imagesSupp = $this->request->getFiles()['photos_supplementaires'] ?? [];

        if (!empty($imagesSupp) && is_array($imagesSupp)) {
            foreach ($imagesSupp as $photo) {
                if ($photo->isValid() && !$photo->hasMoved()) {
                    $name = $photo->getRandomName();
                    $photo->move('uploads/photos_maisons', $name);
                    $chemin = 'uploads/photos_maisons/' . $name;

                    // Insertion dans la table photo
                    $photoModel->insert([
                        'chemin' => $chemin,
                        'IDmaison' => $idMaison
                    ]);
                }
            }
        }

        return redirect()->to('/admin_maisons')->with('success', 'Maison et photos ajoutées avec succès.');
    }

    public function supprimerMaison($id = null)
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') == 'bloque') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }

        $maisonModel = new MaisonModel();

        $maison = $maisonModel->find($id);
        if (!$maison) {
            return redirect()->to('/admin_maisons')->with('error', 'Maison non trouvée.');
        }

        if (!empty($maison['image']) && file_exists($maison['image'])) {
            unlink($maison['image']);
        }

        $maisonModel->delete($id);

        return redirect()->to('/admin_maisons')->with('success', 'Maison supprimée avec succès.');
    }

    public function modifierMaison($id = null)
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') == 'bloque') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }

        $maisonModel = new MaisonModel();
        $photoModel = new \App\Models\PhotoModel();
        $maison = $maisonModel->find($id);

        if (!$maison) {
            return redirect()->to('/admin_maisons')->with('error', 'Maison introuvable.');
        }

        $photos = $photoModel->where('IDmaison', $id)->findAll();

        return view('admin_maisons/modifier', ['maison' => $maison, 'photos' => $photos]);
    }

    public function enregistrerModificationMaison($id = null)
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') == 'bloque') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }

        $maisonModel = new MaisonModel();
        $photoModel = new \App\Models\PhotoModel();
        $maison = $maisonModel->find($id);

        if (!$maison) {
            return redirect()->to('/admin_maisons')->with('error', 'Maison introuvable.');
        }

        $data = [
            'nom' => $this->request->getPost('nom'),
            'description' => $this->request->getPost('description'),
            'ville' => $this->request->getPost('ville'),
            'pays' => $this->request->getPost('pays'),
            'prix_basse' => $this->request->getPost('prix_basse'),
            'prix_moyenne' => $this->request->getPost('prix_moyenne'),
            'prix_haute' => $this->request->getPost('prix_haute'),
        ];


        $image = $this->request->getFile('image');
        if ($image && $image->isValid() && !$image->hasMoved()) {
            if (!empty($maison['image']) && file_exists($maison['image'])) {
                unlink($maison['image']);
            }

            $newName = $image->getRandomName();
            $image->move('uploads/maisons', $newName);
            $data['image'] = 'uploads/maisons/' . $newName;
        }

        $maisonModel->update($id, $data);


        $galerie = $this->request->getFiles();
        if (isset($galerie['galerie'])) {
            foreach ($galerie['galerie'] as $photo) {
                if ($photo->isValid() && !$photo->hasMoved()) {
                    $photoName = $photo->getRandomName();
                    $photo->move('uploads/photos', $photoName);

                    $photoModel->insert([
                        'chemin' => 'uploads/photos/' . $photoName,
                        'IDmaison' => $id
                    ]);
                }
            }
        }

        return redirect()->to('/admin_maisons')->with('success', 'Maison modifiée avec succès.');
    }
}