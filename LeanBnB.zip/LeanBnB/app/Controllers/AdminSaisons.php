<?php

namespace App\Controllers;

use App\Models\SaisonModel;

class AdminSaisons extends BaseController
{
    public function viewSaisons()
    {
        if (!session()->get('isLoggedIn') || session()->get('user_role') !== 'administrateur') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }

        $model = new SaisonModel();
        $saisons = $model->findAll();

        return view('admin_saisons', ['saisons' => $saisons]);
    }

    public function ajouter()
    {
        $model = new SaisonModel();

        $data = [
            'nom'        => $this->request->getPost('nom'),
            'date_debut' => $this->request->getPost('date_debut'),
            'date_fin'   => $this->request->getPost('date_fin')
        ];

        $model->insert($data);

        return redirect()->to('/admin_saisons')->with('success', 'Saison ajoutée.');
    }

    public function modifier($id)
    {
        $model = new SaisonModel();
        $saison = $model->find($id);

        return view('modifier_saison', ['saison' => $saison]);
    }

    public function enregistrerModification($id)
    {
        $model = new SaisonModel();

        $data = [
            'nom'        => $this->request->getPost('nom'),
            'date_debut' => $this->request->getPost('date_debut'),
            'date_fin'   => $this->request->getPost('date_fin')
        ];

        $model->update($id, $data);

        return redirect()->to('/admin_saisons')->with('success', 'Saison modifiée.');
    }
}