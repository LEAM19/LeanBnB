<?php

namespace App\Controllers;

use App\Models\UtilisateurModel;

class AdminUtilisateur extends BaseController
{
    public function gererUtilisateurs()
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') == 'bloque') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }

        $utilisateurModel = new UtilisateurModel();
        $utilisateurs = $utilisateurModel->findAll();

        return view('admin_utilisateurs', ['utilisateurs' => $utilisateurs]);
    }

    public function bloquer($id)
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') == 'bloque') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }

        $utilisateurModel = new UtilisateurModel();
        $utilisateurModel->update($id, ['statut' => 'bloque']);

        return redirect()->to('/admin_utilisateurs')->with('success', 'Utilisateur bloqué.');
    }

    public function debloquer($id)
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') == 'bloque') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }

        $utilisateurModel = new UtilisateurModel();
        $utilisateurModel->update($id, ['statut' => 'debloque']);

        return redirect()->to('/admin_utilisateurs')->with('success', 'Utilisateur débloqué.');
    }

    public function promouvoir($id)
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') == 'bloque') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }

        $utilisateurModel = new UtilisateurModel();
        $utilisateurModel->update($id, ['role' => 'administrateur']);

        return redirect()->to('/admin_utilisateurs')->with('success', 'Utilisateur promu administrateur.');
    }

    public function retrograder($id)
    {
        if (!session()->get('isLoggedIn') || session()->get('user_statut') === 'bloque') {
            return redirect()->to('/')->with('error', 'Accès non autorisé.');
        }

        // Empêcher l'utilisateur de se rétrograder lui-même
        if ($id == session()->get('user_id')) {
            return redirect()->back()->with('error', 'Vous ne pouvez pas vous rétrograder vous-même.');
        }

        $utilisateurModel = new \App\Models\UtilisateurModel();
        $utilisateur = $utilisateurModel->find($id);

        if (!$utilisateur || $utilisateur['role'] !== 'administrateur') {
            return redirect()->back()->with('error', 'L’utilisateur n’est pas un administrateur ou n’existe pas.');
        }

        $utilisateurModel->update($id, ['role' => 'utilisateur']);

        return redirect()->to('/admin_utilisateurs')->with('success', 'Administrateur rétrogradé avec succès.');
    }

    public function anonymiser($id)
    {
        $model = new \App\Models\UtilisateurModel();
        $utilisateur = $model->find($id);

        if (!$utilisateur) {
            return redirect()->back()->with('error', 'Utilisateur introuvable.');
        }
        // Vérifie si l'utilisateur est un administrateur
        if ($utilisateur['role'] === 'administrateur') {
            // Compter le nombre d'administrateurs non supprimés restants
            $nbAdmins = $model
                ->where('role', 'administrateur')
                ->where('statut !=', 'delete')  // Ne compte que les admins actifs
                ->countAllResults();

            if ($nbAdmins <= 1) {
                return redirect()->to('/admin_utilisateurs')->with('error', 'Impossible d\'anonymiser le dernier administrateur.');
            }
        }

        if ($id == session()->get('user_id')) {
            return redirect()->back()->with('error', 'Vous ne pouvez pas vous anonymiser vous-même.');
        }

        if ($model->anonymiser($id)) {
            return redirect()->to('/admin_utilisateurs')->with('success', 'Utilisateur anonymisé avec succès.');
        }

        return redirect()->back()->with('error', 'Échec de l\'anonymisation.');
    }
}