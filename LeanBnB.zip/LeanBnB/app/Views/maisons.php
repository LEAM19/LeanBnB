<!-- View contenant mes maisons dynamiques -->
<?= $this->extend('layout') ?>

<?= $this->section('title') ?>Maisons - LeanBnB<?= $this->endSection() ?>

<?= $this->section('script') ?>
<!-- Bootstrap et JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" defer></script>
<script src="<?= base_url('public/assets/js/maisons.js') ?>" defer></script>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<h1 class="text-center">Nos Maisons</h1>

<div class="text-center my-4">
    <label for="filtre-pays" class="form-label">Filtrer par pays :</label>
    <select id="filtre-pays" class="form-select" style="width: 200px; display: inline-block;">
        <option value="tous">Tous les pays</option>
        <?php
            $paysDispo = array_unique(array_column($maisons, 'pays'));
            foreach ($paysDispo as $pays) :
        ?>
            <option value="<?= esc($pays) ?>"><?= esc($pays) ?></option>
        <?php endforeach; ?>
    </select>
</div>

<!-- ✅ Bloc que le JS mettra à jour via AJAX -->
<div id="contenu-maisons">
    <?= view('partials/maisons_liste', ['maisons' => $maisons]) ?>
</div>

<div style="display: flex; justify-content: center; margin-top: 40px; margin-bottom: 20px;">
    <a href="<?= base_url('/reservation') ?>" class="btn btn-primary" style="width: 940px; max-width: 90%; padding: 15px; font-size: 18px; text-align: center;">
        Réserver une maison
    </a>
</div>

<?= $this->endSection() ?>