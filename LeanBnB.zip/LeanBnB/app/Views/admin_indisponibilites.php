<?= $this->extend('layout') ?>

<?= $this->section('title') ?>Périodes d'indisponibilité - Admin<?= $this->endSection() ?>

<?= $this->section('script') ?>
<script src="<?= base_url('public/assets/js/admin_indisponibilites.js') ?>"></script>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="container">
    <h1 class="text-center my-4">Gérer les périodes d’indisponibilité</h1>

    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success text-center"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>

    <form action="<?= base_url('/admin_indisponibilites/ajouter') ?>" method="post" class="mb-4">
        <div class="row">
            <div class="col-md-4">
                <label for="IDmaison">Maison</label>
                <select name="IDmaison" class="form-control" required>
                    <option value="">-- Choisir une maison --</option>
                    <?php foreach ($maisons as $maison): ?>
                        <option value="<?= esc($maison['IDmaison']) ?>"><?= esc($maison['nom']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label for="date_debut">Date de début</label>
                <input type="date" name="date_debut" class="form-control" required>
            </div>
            <div class="col-md-3">
                <label for="date_fin">Date de fin</label>
                <input type="date" name="date_fin" class="form-control" required>
            </div>
            <div class="col-md-2">
                <label for="motif">Motif</label>
                <input type="text" name="motif" class="form-control" placeholder="facultatif">
            </div>
        </div>
        <div class="text-center mt-3">
            <button type="submit" class="btn btn-primary">Ajouter</button>
        </div>
    </form>

    <?php if (!empty($indisponibilites)): ?>
    <table id="table-utilisateurs" class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Maison</th>
                <th>Date début</th>
                <th>Date fin</th>
                <th>Motif</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($indisponibilites as $indispo): ?>
                <tr>
                    <td><?= esc($indispo['nom_maison']) ?></td>
                    <td><?= esc($indispo['date_debut']) ?></td>
                    <td><?= esc($indispo['date_fin']) ?></td>
                    <td><?= esc($indispo['motif']) ?></td>
                    <td>
                        <a href="<?= base_url('/admin_indisponibilites/modifier/' . $indispo['IDindisponibilite']) ?>"
                        class="btn btn-sm btn-primary">Modifier</a>

                        <a href="<?= base_url('/admin_indisponibilites/supprimer/' . $indispo['IDindisponibilite']) ?>"
                        class="btn btn-sm btn-outline-terra" onclick="return confirm('Supprimer cette période d’indisponibilité ?');">Supprimer</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p class="text-center">Aucune période d’indisponibilité enregistrée.</p>
<?php endif; ?>
</div>
<?= $this->endSection() ?>