<?= $this->extend('layout') ?>

<?= $this->section('title') ?>Mes Réservations<?= $this->endSection() ?>

<?= $this->section('script') ?>
<script src="<?= base_url('public/assets/js/reservation.js') ?>"></script>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<h1 class="text-center">Mes Réservations</h1>

<?php if (session()->getFlashdata('success')) : ?>
    <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
<?php endif; ?>

<?php if (!empty($reservations) && is_array($reservations)) : ?>
    <table id="table-utilisateurs" class="table table-striped">
        <thead>
            <tr>
                <th>Maison</th>
                <th>Date d'arrivée</th>
                <th>Date de départ</th>
                <th>Montant</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($reservations as $resa) : ?>
                <?php if ($resa['statut'] != 'annulée') : ?>
                    <tr>
                        <td><?= esc($resa['nom']) ?></td>
                        <td><?= esc($resa['date_arrive']) ?></td>
                        <td><?= esc($resa['date_depart']) ?></td>
                        <td><?= esc($resa['montant']) ?> €</td>
                        <td>
                            <?php if ($resa['statut'] == 'en attente') : ?>
                                <form action="<?= base_url('reservation/payer/' . $resa['IDreservation']) ?>" method="post" style="display:inline;">
                                    <button type="submit" class="btn btn-success btn-sm">J'ai payé</button>
                                </form>
                            <?php endif; ?>
                            <a href="<?= base_url('/reservation/modifier/' . $resa['IDreservation']) ?>" class="btn btn-primary btn-sm">Modifier</a>
                            <a href="<?= base_url('/reservation/annuler/' . $resa['IDreservation']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir annuler cette réservation ?');">Annuler </a>
                        </td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else : ?>
    <p class="text-center">Vous n’avez pas encore de réservations.</p>
<?php endif; ?>

<?= $this->endSection() ?>
