<!--View contenant mon formulaire d'inscription-->
<?= $this->extend('layout') ?>

<?= $this->section('title') ?>Inscription - LeanBnB<?= $this->endSection() ?>

<?= $this->section('script') ?>
    <script src="<?= base_url('public/assets/js/inscription.js') ?>" defer></script> <!--Defer permet de charger le html en parallèle du JS-->
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<h1 class="mb-4">Inscription</h1>

    <?php if (session()->getFlashdata('error')) : ?>
        <div class="alert alert-danger text-center">
            <?= session()->getFlashdata('error') ?>
        </div>
    <?php endif; ?>

    <p class="mb-4">Pour vous inscrire sur LeanBnB, veuillez entrer les informations nécessaires à votre identification.</p>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <form action="<?= base_url('/inscription') ?>" method="post" enctype="multipart/form-data" class="p-4 border rounded bg-light shadow">
                    
                    <div class="mb-3">
                        <label for="nom" class="form-label">Nom :</label>
                        <input type="text" id="nom" name="nom" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label for="prenom" class="form-label">Prénom :</label>
                        <input type="text" id="prenom" name="prenom" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label for="telephone" class="form-label">Téléphone :</label>
                        <input type="text" id="telephone" name="telephone" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">Email :</label>
                        <input type="email" id="email" name="email" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Mot de passe :</label>
                        <input type="password" id="password" name="password" class="form-control" required>
                        <button class="btn btn-outline-secondary" type="button" id="BoutonEye">
                        <i class="bi bi-eye"></i>
                        </button>
                    </div>

                    <div class="mb-3">
                        <label for="photo_profil" class="form-label">Photo de profil :</label>
                        <input type="file" id="photo_profil" name="photo_profil" class="form-control">
                    </div>

                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">S'inscrire</button>
                    </div>  
                </form>
            </div>
        </div>
    </div>
    


<?= $this->endSection() ?>