<?= $this->extend('layout') ?>
<?= $this->section('title') ?>Modifier une indisponibilité<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="container mt-4">
    <h2 class="mb-4">Modifier une indisponibilité</h2>
    <form action="<?= base_url('/admin_indisponibilites/modifier/' . $indisponibilite['IDindisponibilite']) ?>" method="post">
        <div class="mb-3">
            <label for="IDmaison" class="form-label">Maison</label>
            <select name="IDmaison" class="form-select" required>
                <?php foreach ($maisons as $maison): ?>
                    <option value="<?= $maison['IDmaison'] ?>"
                        <?= $maison['IDmaison'] == $indisponibilite['IDmaison'] ? 'selected' : '' ?>>
                        <?= esc($maison['nom']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="date_debut">Date de début</label>
            <input type="date" name="date_debut" class="form-control" value="<?= esc($indisponibilite['date_debut']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="date_fin">Date de fin</label>
            <input type="date" name="date_fin" class="form-control" value="<?= esc($indisponibilite['date_fin']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="motif">Motif</label>
            <input type="text" name="motif" class="form-control" value="<?= esc($indisponibilite['motif']) ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Enregistrer</button>
        <a href="<?= base_url('/admin_indisponibilites') ?>" class="btn btn-outline-terra">Annuler</a>
    </form>
</div>
<?= $this->endSection() ?>