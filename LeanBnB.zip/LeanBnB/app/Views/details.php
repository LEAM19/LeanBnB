<?= $this->extend('layout') ?>

<?= $this->section('title') ?>Accueil - LeanBnB<?= $this->endSection() ?>

<?= $this->section('script') ?>
<!-- Inclure le fichier js si nécessaire -->
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="container text-center my-5">
    <h1 class="mb-4">Bienvenue sur <strong>LeanBnB</strong></h1>
    <p>Votre plateforme de confiance pour la réservation de maisons de vacances.</p>

    <div class="my-4">
        <h4>Réservez en quelques clics</h4>
        <p>Choisissez votre destination, sélectionnez vos dates et profitez d’un séjour inoubliable.</p>
    </div>

    <div class="d-flex justify-content-center gap-3 mt-4">
        <a href="<?= base_url('/maisons') ?>" class="btn btn-outline-terra">Découvrir les maisons</a>
        <a href="<?= base_url('/reservation') ?>" class="btn btn-primary">Réserver maintenant</a>
    </div>
</div>

<?= $this->endSection() ?>