<?= $this->extend('layout') ?>

<?= $this->section('title') ?> Tableau de bord - LeanBnB <?= $this->endSection() ?>

<?= $this->section('script') ?>
    <script src="<?= base_url('public/assets/js/dashboard.js') ?>" defer></script>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<?php if (!session()->get('isLoggedIn')) {
        return redirect()->to('/authentification');
    } ?>
    <div class="container mt-4">
        <h1 class="mb-4">Mon Profil</h1>

        <div class="card p-4 shadow-sm">
            <div class="row">
                <div class="col-md-3 text-center">
                <?php
                    $photo = session()->get('user_photo');
                    $photoPath = $photo ? base_url($photo) : base_url('public/images/avatar-default.png');
                    ?>

                    <img src="<?= $photoPath ?>" alt="Photo de profil" class="img-fluid rounded-circle" style="max-width: 150px;">

                </div>
                <div class="col-md-9">
                    <h4><?= session()->get('user_prenom') . ' ' . session()->get('user_nom') ?></h4>
                    <p><strong>Email :</strong> <?= session()->get('user_email') ?></p>
                    <p><strong>Téléphone :</strong> <?= session()->get('user_telephone') ?? 'Non renseigné' ?></p>
                    <p><strong>Rôle :</strong> <?= session()->get('user_role') ?? 'Utilisateur' ?></p>
                </div>
                <div class="mt-3">
                    <a href="<?= base_url('/modifier_profil') ?>" class="btn btn-outline-secondary">Modifier mon profil</a>
                </div>
            </div>
        </div>
    </div>
<?= $this->endSection() ?>