<?= $this->extend('layout') ?>

<?= $this->section('title') ?>Gestion des Utilisateurs - Admin<?= $this->endSection() ?>

<?= $this->section('script') ?>
<script src="<?= base_url('public/assets/js/admin_utilisateurs.js') ?>"></script>
<?= $this->endSection() ?>


<?= $this->section('content') ?>

<h1 class="text-center my-4">Gestion des Utilisateurs</h1>

<div class="container my-5">
    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success">
            <?= session()->getFlashdata('success') ?>
        </div>
    <?php endif; ?>

    <table id="table-utilisateurs" class="table table-striped table-hover">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nom</th>
                <th>Email</th>
                <th>Statut</th>
                <th>Rôle</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($utilisateurs as $utilisateur): ?>
                <tr>
                    <td><?= esc($utilisateur['IDutilisateur']) ?></td>
                    <td><?= esc($utilisateur['nom']) ?></td>
                    <td><?= esc($utilisateur['email']) ?></td>
                    <td>
                        <?php if ($utilisateur['statut'] == 'bloque'): ?>
                            <span class="badge bg-danger">Bloqué</span>
                        <?php elseif ($utilisateur['statut'] == 'delete'): ?>
                            <span class="badge bg-danger">Supprimé</span>
                        <?php else: ?>
                            <span class="badge bg-success">Actif</span>
                        <?php endif; ?>
                    </td>
                    <td><?= ucfirst(esc($utilisateur['role'])) ?></td>
                    <td>
                        <?php if ($utilisateur['statut'] != 'delete'): ?>
                            <?php if ($utilisateur['statut'] == 'debloque'): ?>
                                <a href="<?= base_url('admin_utilisateurs/bloquer/' . $utilisateur['IDutilisateur']) ?>" class="btn btn-warning btn-sm mb-1">Bloquer</a>
                            <?php elseif ($utilisateur['statut'] == 'bloque'): ?>
                                <a href="<?= base_url('admin_utilisateurs/debloquer/' . $utilisateur['IDutilisateur']) ?>" class="btn btn-success btn-sm mb-1">Débloquer</a>
                            <?php endif; ?>
                        <?php endif; ?>

                       <?php if ($utilisateur['role'] == 'utilisateur' && $utilisateur['statut'] != 'delete'): ?>
                            <a href="<?= base_url('admin_utilisateurs/promouvoir/' . $utilisateur['IDutilisateur']) ?>" class="btn btn-primary btn-sm">Promouvoir</a>
                        <?php endif; ?>

                        <?php if ($utilisateur['statut'] != 'delete'): ?>
                            <a href="<?= base_url('admin_utilisateurs/anonymiser/' . $utilisateur['IDutilisateur']) ?>" 
                                class="btn btn-danger btn-sm mt-1"
                                onclick="return confirm('Anonymiser cet utilisateur ? Cela effacera ses données personnelles, mais conservera ses réservations.')">
                                Anonymiser
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?= $this->endSection() ?>