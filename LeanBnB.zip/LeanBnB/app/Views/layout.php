<!--CECI EST MON LAYOUT ME PERMETTANT DE CENTRALISER MA NAVBAR ET MON FOOTER-->
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $this->renderSection('title') ?? 'LeanBnB' ?></title>
    <base href="<?= base_url() ?>">

    <!--Inclusion de mon CSS-->
    <script src="<?= base_url('public/assets/js/jquery-3.7.1.min.js') ?>"></script>
    <script src="<?= base_url('public/assets/js/dataTables.min.js') ?>"></script>
    <link rel="stylesheet" href="<?= base_url('public/bootstrap/css/bootstrap.min.css') ?>">
    <link rel="stylesheet" href="<?= base_url('public/bootstrap/icons/bootstrap-icons.css') ?>">
    <link rel="stylesheet" href="<?= base_url('public/assets/css/dataTables.min.css') ?>">
    <link rel="stylesheet" href="<?= base_url('public/assets/css/style.css') ?>">

    <!--Inclusion dynamique du js pour chaque page-->
    <?= $this->renderSection('script') ?>
</head>

<body class="d-flex flex-column min-vh-100">
    <header>

        <!--Navbar-->
        <nav class="navbar navbar-expand-lg navbar-light navbar-custom">
            <div class="container-fluid d-flex justify-content-center">
                <ul class="nav nav-pills">
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('/') ?>">Accueil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('/maisons') ?>">Maisons</a>
                </li>
                <!--Si je suis connecté affiche aussi les boutons mon profil et déconnexion-->
                <?php if (session()->get('isLoggedIn')): ?>
                
                <?php if (session()->get('user_role') === 'administrateur'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('/admin') ?>">Espace administrateur</a>
                    </li>
                <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('/mes_reservations') ?>">Mes réservation</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('/dashboard') ?>">Mon Profil</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('/logout') ?>">Déconnexion</a>
                    </li>
                <?php else: ?>
                <!--Sinon affiche connexion-->
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('/authentification') ?>">Connexion</a>
                    </li>
                <?php endif; ?>
                
                </ul>
            </div>
        </nav>
    </header>

    <main class="flex-grow-1 d-flex flex-column justify-content-center align-items-center text-center">
        <?= $this->renderSection('content') ?> <!--Section qui va contenir mon contenue-->
    </main>

    
    <footer>
        <p class="mb-0">&copy; <?= date('Y') ?> LeanBnB - Tous droits réservés</p>
    </footer>
</body>
</html>