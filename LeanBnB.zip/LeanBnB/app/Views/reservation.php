<!-- Page de réservation -->
<?= $this->extend('layout') ?>

<?= $this->section('title') ?>Réservation - LeanBnB<?= $this->endSection() ?>

<?= $this->section('script') ?>
    <script src="<?= base_url('public/assets/js/reservation.js') ?>" defer></script>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<h1 class="text-center">Réserver votre séjour</h1>

<?php if (session()->getFlashdata('error')) : ?>
    <div class="alert alert-danger text-center">
        <?= session()->getFlashdata('error') ?>
    </div>
<?php endif; ?>

<div style="max-width: 600px; margin: auto;">
    <form action="<?= base_url('reservation/submit') ?>" method="post">
        <div class="form-group">
            <label for="maison">Maison</label>
            <select id="maison" name="maison" class="form-control" required>
                <option value="">-- Choisissez une maison --</option>
                <?php foreach ($maisons as $maison): ?>
                    <option
                        value="<?= esc($maison['IDmaison']) ?>"
                        data-prixbasse="<?= esc($maison['prix_basse']) ?>"
                        data-prixmoyenne="<?= esc($maison['prix_moyenne']) ?>"
                        data-prixhaute="<?= esc($maison['prix_haute']) ?>">
                        <?= esc($maison['nom']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="date_debut">Date d'arrivée</label>
            <input type="date" id="date_debut" name="date_debut" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="date_fin">Date de départ</label>
            <input type="date" id="date_fin" name="date_fin" class="form-control" required>
        </div>

        <div id="resume" style="margin-top: 20px; display: none; border: 1px solid #ccc; padding: 15px;">
            <h4>Récapitulatif de votre commande</h4>
            <p><strong>Maison :</strong> <span id="recap-maison"></span></p>
            <p><strong>Dates :</strong> <span id="recap-dates"></span></p>
            <p><strong>Saison estimée :</strong> <span id="recap-saison"></span></p>
            <p><strong>Tarif par nuit :</strong> <span id="recap-tarif"></span> €</p>
            <p><strong>Nombre de nuits :</strong> <span id="recap-nuits"></span></p>
            <p><strong>Montant total :</strong> <span id="recap-total"></span> €</p>
        </div>

        <input type="hidden" name="montant" id="montant">
        <input type="hidden" name="IDmaison" id="IDmaison">

        <div class="text-center mt-3">
            <button type="submit" class="btn btn-primary">Valider la réservation</button>
        </div>
    </form>
</div>

<?= $this->endSection() ?>