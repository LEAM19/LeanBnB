<?= $this->extend('layout') ?>

<?= $this->section('title') ?>Gestion des Maisons - Admin<?= $this->endSection() ?>

<?= $this->section('script') ?>
<script src="<?= base_url('public/assets/js/admin_maisons.js') ?>"></script>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<h1 class="text-center mb-4">Gestion des Maisons</h1>

<?php if (session()->getFlashdata('success')) : ?>
    <div class="alert alert-success text-center"><?= session()->getFlashdata('success') ?></div>
<?php endif; ?>

<?php if (session()->getFlashdata('error')) : ?>
    <div class="alert alert-danger text-center"><?= session()->getFlashdata('error') ?></div>
<?php endif; ?>

<div class="text-center mb-4">
    <a href="<?= base_url('/admin_maisons/ajouter') ?>" class="btn btn-success">Ajouter une maison</a>
</div>

<?php if (!empty($maisons) && is_array($maisons)) : ?>
    <div class="table-responsive">
        <table id="table-utilisateurs" class="table table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>Nom</th>
                    <th>Pays</th>
                    <th>Description</th>
                    <th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($maisons as $maison) : ?>
                    <tr>
                        <td><?= esc($maison['nom']) ?></td>
                        <td><?= esc($maison['pays']) ?></td>
                        <td><?= esc($maison['description']) ?></td>
                        <td class="text-center">
                            <a href="<?= base_url('/admin_maisons/modifier/' . $maison['IDmaison']) ?>" class="btn btn-sm btn-outline-terra">Modifier</a>
                            <a href="<?= base_url('/admin_maisons/supprimer/' . $maison['IDmaison']) ?>" class="btn btn-sm btn-primary" onclick="return confirm('Supprimer cette maison ?');">Supprimer</a>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
<?php else : ?>
    <p class="text-center">Aucune maison n’est enregistrée pour le moment.</p>
<?php endif; ?>

<?= $this->endSection() ?>
