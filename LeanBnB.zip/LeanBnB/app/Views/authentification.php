<?= $this->extend('layout') ?>

<?= $this->section('title') ?>Connexion - LeanBnB<?= $this->endSection() ?>

<?= $this->section('script') ?>
<script src="<?= base_url('public/assets/js/authentification.js') ?>" defer></script>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="container">

<?php if (session()->getFlashdata('error')): ?>
    <div class="alert alert-danger">
        <?= session()->getFlashdata('error') ?>
    </div>
<?php endif; ?>

<?php if (session()->getFlashdata('success')): ?>
    <div class="alert alert-success">
        <?= session()->getFlashdata('success') ?>
    </div>
<?php endif; ?>

    <h1 class="mb-4">Connexion</h1>

    <p class="mb-4">Connectez-vous à LeanBnB</p>

    <div class="row justify-content-center">
        <div class="col-md-6">
            <form action="<?= base_url('/authentification') ?>" method="post" class="p-4 border rounded bg-light shadow">
                <div class="mb-3">
                    <label for="email">Email :</label>
                    <input type="email" id="email" name="email" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="password">Mot de passe :</label>
                    <input type="password" id="password" name="password" class="form-control" required>
                    <button class="btn btn-outline-secondary" type="button" id="BoutonEye">
                        <i class="bi bi-eye"></i>
                    </button>
                </div>
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-secondary">Se connecter</button>
                </div>
            </form>
        </div>
    </div>

    <p>Vous n'êtes pas encore inscrit ? <a href="<?= base_url('/inscription') ?>">Créer un compte</a></p>

</div>

<?= $this->endSection() ?>