<?= $this->extend('layout') ?>

<?= $this->section('title') ?>Gestion des Saisons<?= $this->endSection() ?>

<?= $this->section('script') ?>
<script src="<?= base_url('public/assets/js/admin_saisons.js') ?>"></script>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="container my-5">
    <h1 class="mb-4 text-center">Gestion des Saisons</h1>

    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">Ajouter une saison</div>
        <div class="card-body">
            <form action="<?= base_url('/admin_saisons/ajouter') ?>" method="post">
                <div class="mb-3">
                    <label for="nom" class="form-label">Nom de la saison</label>
                    <select name="nom" class="form-select" required>
                        <option value="">--Choisir--</option>
                        <option value="basse">Basse</option>
                        <option value="moyenne">Moyenne</option>
                        <option value="haute">Haute</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="date_debut" class="form-label">Date de début</label>
                    <input type="date" name="date_debut" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="date_fin" class="form-label">Date de fin</label>
                    <input type="date" name="date_fin" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary">Ajouter la saison</button>
            </form>
        </div>
    </div> 

    <h3 class="mb-3">Saisons enregistrées</h3>
    <?php if (!empty($saisons)) : ?>
        <table id="table-utilisateurs" class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Début</th>
                    <th>Fin</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($saisons as $saison): ?>
                    <tr>
                        <td><?= esc(($saison['nom'])) ?></td>
                        <td><?= esc($saison['date_debut']) ?></td>
                        <td><?= esc($saison['date_fin']) ?></td>
                        <td>
                            <a href="<?= base_url('/admin_saisons/modifier/' . $saison['IDsaison']) ?>" class="btn btn-sm btn-primary">Modifier</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else : ?>
        <p class="text-muted">Aucune saison enregistrée.</p>
    <?php endif; ?>
</div>
<?= $this->endSection() ?>