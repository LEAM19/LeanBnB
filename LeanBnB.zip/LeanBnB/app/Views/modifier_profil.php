<?= $this->extend('layout') ?>

<?= $this->section('title') ?>Modifier mon profil<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="container mt-4">
    <h1 class="mb-4">Modifier mon profil</h1>

    <?php if (session()->getFlashdata('success')) : ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>
    <?php if (session()->getFlashdata('error')) : ?>
        <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>

    <form action="<?= base_url('/modifier_profil') ?>" method="post" enctype="multipart/form-data">
        <?= csrf_field() ?>

        <div class="mb-3">
            <label for="prenom" class="form-label">Prénom</label>
            <input type="text" class="form-control" name="prenom" value="<?= session()->get('user_prenom') ?>">
        </div>

        <div class="mb-3">
            <label for="nom" class="form-label">Nom</label>
            <input type="text" class="form-control" name="nom" value="<?= session()->get('user_nom') ?>">
        </div>

        <div class="mb-3">
            <label for="telephone" class="form-label">Téléphone</label>
            <input type="text" class="form-control" name="telephone" value="<?= session()->get('user_telephone') ?>">
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">Adresse email</label>
            <input type="email" class="form-control" name="email" value="<?= session()->get('user_email') ?>">
        </div>


        <div class="mb-3">
            <label for="new_password" class="form-label">Nouveau mot de passe</label>
            <input type="password" class="form-control" name="new_password" placeholder="Entrez le nouveau mot de passe">
        </div>

        <div class="mb-3">
            <label for="confirm_password" class="form-label">Confirmer le nouveau mot de passe</label>
            <input type="password" class="form-control" name="confirm_password" placeholder="Confirmer le nouveau mot de passe">
        </div>

        <div class="mb-3">
            <label for="photo_profil" class="form-label">Photo de profil</label><br>
            <img src="<?= base_url(session()->get('user_photo')) ?>" alt="Actuelle" width="100" class="rounded mb-2"><br>
            <input type="file" class="form-control" name="photo_profil">
        </div>

                <button type="submit" class="btn btn-outline-terra">Enregistrer les modifications</button>
            </form>
        </div>

<?= $this->endSection() ?>
