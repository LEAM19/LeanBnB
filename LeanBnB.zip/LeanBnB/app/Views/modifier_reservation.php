<?= $this->extend('layout') ?>

<?= $this->section('title') ?>Modifier Réservation - LeanBnB<?= $this->endSection() ?>

<?= $this->section('content') ?>

<h1 class="text-center">Modifier votre réservation</h1>

<div style="max-width: 600px; margin: auto;">
    <form action="<?= base_url('reservation/modifier/' . $reservation['IDreservation']) ?>" method="post">
        
        <div class="form-group mb-3">
            <label for="maison">Maison</label>
            <select id="maison" name="maison" class="form-control" required>
                <option value="">-- Choisissez une maison --</option>
                <?php foreach ($maisons as $maison): ?>
                    <option 
                        value="<?= esc($maison['IDmaison']) ?>" 
                        <?= $maison['IDmaison'] == $reservation['IDmaison'] ? 'selected' : '' ?>>
                        <?= esc($maison['nom']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group mb-3">
            <label for="date_debut">Date d'arrivée</label>
            <input 
                type="date" 
                id="date_debut" 
                name="date_debut" 
                class="form-control" 
                required 
                value="<?= esc($reservation['date_arrive']) ?>">
        </div>

        <div class="form-group mb-4">
            <label for="date_fin">Date de départ</label>
            <input 
                type="date" 
                id="date_fin" 
                name="date_fin" 
                class="form-control" 
                required 
                value="<?= esc($reservation['date_depart']) ?>">
        </div>

        <div class="text-center">
            <button type="submit" class="btn btn-outline-primary">Enregistrer les modifications</button>
            <a href="<?= base_url('/mes_reservations') ?>" class="btn btn-outline-secondary ms-2">Annuler</a>
        </div>
    </form>
</div>

<?= $this->endSection() ?>
