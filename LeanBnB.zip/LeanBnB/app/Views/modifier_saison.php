<?= $this->extend('layout') ?>

<?= $this->section('title') ?>Modifier Saison<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="container my-5">
    <h1 class="mb-4 text-center">Modifier la Saison</h1>

    <form action="<?= base_url('/admin_saisons/modifier/' . $saison['IDsaison']) ?>" method="post">
        <div class="mb-3">
            <label for="nom" class="form-label">Nom de la saison</label>
            <select name="nom" class="form-select" required>
                <option value="basse" <?= $saison['nom'] === 'basse' ? 'selected' : '' ?>>Basse</option>
                <option value="moyenne" <?= $saison['nom'] === 'moyenne' ? 'selected' : '' ?>>Moyenne</option>
                <option value="haute" <?= $saison['nom'] === 'haute' ? 'selected' : '' ?>>Haute</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="date_debut" class="form-label">Date de début</label>
            <input type="date" name="date_debut" class="form-control" value="<?= esc($saison['date_debut']) ?>" required>
        </div>

        <div class="mb-3">
            <label for="date_fin" class="form-label">Date de fin</label>
            <input type="date" name="date_fin" class="form-control" value="<?= esc($saison['date_fin']) ?>" required>
        </div>

        <button type="submit" class="btn btn-primary">Enregistrer les modifications</button>
        <a href="<?= base_url('/admin_saisons') ?>" class="btn btn-secondary">Annuler</a>
    </form>
</div>
<?= $this->endSection() ?>