console.log("Le DOM de la page inscription est chargé !");
let BoutonCacher = document.getElementById("BoutonEye");

if (BoutonCacher) {
    BoutonCacher.addEventListener("click", function () {
        let passwordInput = document.getElementById("password");
        let icon = this.querySelector("i");

        if (passwordInput.type === "password") {
            passwordInput.type = "text";  // Afficher le mot de passe
            icon.classList.remove("bi-eye");
            icon.classList.add("bi-eye-slash");  // Changer l'icône
        } else {
            passwordInput.type = "password";  // Cacher le mot de passe
            icon.classList.remove("bi-eye-slash");
            icon.classList.add("bi-eye");  // Revenir à l'œil ouvert
        }
    });
}
