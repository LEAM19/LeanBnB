document.addEventListener('DOMContentLoaded', function () {
    const baseUrl = window.location.origin + '/LeanBnB';

    const maisonSelect = document.getElementById('maison');
    const dateDebut = document.getElementById('date_debut');
    const dateFin = document.getElementById('date_fin');
    const montantInput = document.getElementById('montant');
    const maisonInputHidden = document.getElementById('IDmaison');

    function updateRecap() {
        const maison = maisonSelect?.options[maisonSelect.selectedIndex];
        const debut = dateDebut?.value;
        const fin = dateFin?.value;

        if (!maison?.value || !debut || !fin) return;

        const nbNuits = (new Date(fin) - new Date(debut)) / (1000 * 60 * 60 * 24);
        if (nbNuits <= 0) return;

        fetch(baseUrl + '/get-saison', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ date: debut })
        })
        .then(res => res.json())
        .then(data => {
            const saison = data.saison; // attend 'basse', 'moyenne', 'haute'
            const prix = parseFloat(maison.dataset['prix' + saison]);

            document.getElementById('recap-maison').textContent = maison.text;
            document.getElementById('recap-dates').textContent = `${debut} au ${fin}`;
            document.getElementById('recap-saison').textContent = saison.charAt(0).toUpperCase() + saison.slice(1);
            document.getElementById('recap-tarif').textContent = prix.toFixed(0);
            document.getElementById('recap-nuits').textContent = nbNuits;
            document.getElementById('recap-total').textContent = (prix * nbNuits).toFixed(0);

            montantInput.value = (prix * nbNuits).toFixed(0);
            maisonInputHidden.value = maison.value;

            document.getElementById('resume').style.display = 'block';
        })
        .catch(error => {
            console.error("Erreur saison:", error);
        });
    }

    // Initialisation des événements si les éléments existent
    if (maisonSelect && dateDebut && dateFin) {
        maisonSelect.addEventListener('change', updateRecap);
        dateDebut.addEventListener('change', updateRecap);
        dateFin.addEventListener('change', updateRecap);
    }

    // Activation de DataTables
    const table = document.getElementById('table-utilisateurs');
    if (table && typeof $ !== 'undefined' && $.fn.DataTable) {
        $('#table-utilisateurs').DataTable({
            language: {
                url: '/LeanBnB/public/assets/js/fr-FR.json'
            }
        });
    }
});
