document.addEventListener('DOMContentLoaded', function () {
    $('#table-utilisateurs').DataTable({
        language: {
            url: '/LeanBnB/public/assets/js/fr-FR.json'
        }
    });
});